package com.tech.PlamingGo_dao;

public interface PDao {

}
