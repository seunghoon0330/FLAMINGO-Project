package com.tech.PlamingGo;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	
	@Autowired //어노테이션 설정
	private SqlSession SqlSession;
	
	@RequestMapping("/notice")
	public String notice(Model model) {
		return "notice";
	}
}
