package com.tech.PlamingGo;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	
	@Autowired //어노테이션 설정
	private SqlSession SqlSession;
	
	
	/*
	 * @RequestMapping("/customer") public String customer(Model model) { return
	 * "customer"; }
	 * 
	 * @RequestMapping("/customer2") public String customer2(Model model) { return
	 * "customer2"; }
	 */
	@RequestMapping("/noticeboard")
	public String noticeboard(Model model) {
		return "noticeboard";
	}
}
